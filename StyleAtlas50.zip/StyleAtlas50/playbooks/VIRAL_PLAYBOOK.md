# Viral playbook

Read this before you pick a style. The style is the wrapper. These rules do the work.

## Be clear about what no one can promise
No video, from any tool, can guarantee a 100 percent open rate, retention, share rate or sales. Platforms rank on viewer behaviour, and viewers differ. What you can do is stack the mechanics that raise those numbers and test. This pack builds the mechanics into every prompt.

## The seven levers

| Goal | Lever | What the prompt builds in |
|---|---|---|
| Open (stop the scroll) | A first frame with motion and a specific claim | Hook in 0 to 1.5 s, no logo intro |
| Retention | A change every 1 to 2 s plus an open loop | Pattern interrupts, one idea per beat, payoff held to the last 20 percent |
| Watch time | Short length plus a seamless loop | 12 to 30 s default, last frame flows into first |
| Replays | Density and a loop | A takeaway that rewards a second look |
| Saves | A screenshot-worthy rule or checklist | Takeaway line built for saving |
| Shares | Identity or usefulness | A "send this to someone who..." line, or a stat that makes the sender look smart |
| Comments and replies | A cheap, low-stakes question | Optional either/or tag at the end |
| Buying | Problem, result, one action | A single CTA end card, no fake claims |

## Timing template for a 20 second piece

- 0.0 to 1.5 s: hook line and first motion
- 1.5 to 2.5 s: hook shrinks into the corner header
- 2.5 to 8 s: setup beats, change every 1 to 2 s
- 8 to 10 s: tease the payoff again
- 10 to 12 s: re-hook with a reversal or bigger number
- 12 to 16 s: build to the key moment
- 16 s: emphasis move plus biggest sound hit
- 16.5 to 19 s: takeaway, share line, CTA if selling
- 19 to 20 s: last frame matches the first frame so the loop is seamless

## Rules that keep trust
- Never invent testimonials, results or statistics.
- If a number is an assumption, say so in the storyboard step.
- One CTA only.

## How to test
1. Make 3 versions that differ only in the hook line.
2. Post at similar times.
3. Keep the one with the best 3 second hold and the best average view duration.
4. Repeat with the next variable: length, then style.
