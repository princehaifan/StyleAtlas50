# Brief template (copy into the top of any prompt)

TOPIC / SCRIPT:
WHO IT IS FOR:
GOAL: share | follow | sell | teach
THE ONE THING THEY MUST REMEMBER:
CALL TO ACTION:
LENGTH: 20 seconds

## Worked example
TOPIC / SCRIPT: How compound interest works
WHO IT IS FOR: 20 to 30 year olds who have never invested
GOAL: share
THE ONE THING THEY MUST REMEMBER: Time does more than amount
CALL TO ACTION: none
LENGTH: 20 seconds

## Picking a style fast
- Teaching a process: Whiteboard Marker, Blueprint Technical, Infographic Flat
- Cozy or friendly: Felt and Stitch, Crayon Kid Drawing, Soft 3D Clay
- Tech and AI: Cyberpunk HUD, Terminal Hacker, Hidden-Line Wireframe
- Selling: Glassmorphism UI, Infographic Flat, Art Deco Gold
- Fast text hits: Kinetic Typography, Swiss Grid Typographic
- Awe and beauty: Neon Particle Galaxy, Stained Glass Window, Watercolor Bloom
- Mystery: Film Noir Spotlight, Newspaper Collage
- Nostalgia and humour: Windows 95 Desktop, VHS Camcorder, 8-Bit Pixel Quest
