# Hook bank (first 1.5 seconds)

Swap the brackets. Keep it under 8 words on screen.

## Curiosity gap
1. Nobody explains why [thing] works.
2. The real reason [thing] happens.
3. [Thing] is not what you think.
4. Watch what happens at step 3.
5. This one detail changes everything.
6. Here is what they leave out.
7. Why does [thing] always [surprise]?
8. The part nobody tells you about [thing].

## Contrarian
9. Stop doing [common habit].
10. [Popular advice] is wrong.
11. You have been [verb] it backwards.
12. Everyone gets [thing] wrong.
13. [Big name thing] is a trap.
14. You do not need [expensive thing].

## Number and proof
15. [Number] seconds to understand [thing].
16. [Number] steps. That is all.
17. From [low number] to [high number].
18. [Number] percent of people miss this.
19. The [number] rule behind [thing].
20. [Number] mistakes that cost you [thing].

## Stakes
21. This costs you [thing] every day.
22. Do this before [deadline or event].
23. If you [do X], read this first.
24. One mistake. [Big consequence].
25. Do not [action] until you see this.

## Before and after
26. Before: [pain]. After: [gain].
27. Same [input]. Different [result].
28. Day 1 versus day 30.
29. Watch [thing] fix itself.
30. This is what [better] looks like.

## Identity
31. If you are a [type of person], this is for you.
32. Only [group] knows this.
33. For anyone who [struggle].
34. Send this to your [role].
35. Which [type] are you?

## Question
36. What if [surprising premise]?
37. Can you spot the mistake?
38. How does [thing] actually work?
39. Why is [thing] so [adjective]?
40. Would you pay [price] for [thing]?

## Demonstration
41. Watch this.
42. Look closely.
43. Here is [thing] in [short time].
44. Three. Two. One.
45. Ready for the twist?

## Story
46. I tried [thing] for [time].
47. It started with [small thing].
48. This happened when we [action].
49. The day [event] changed.
50. Nobody believed [claim]. Then this.
