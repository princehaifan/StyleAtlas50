# Share, save, comment and buy triggers

Pick one per video. Do not stack more than two.

## Share lines (on screen near the end)
- Send this to someone who still [old habit].
- Show this to your [role] before Monday.
- Save for the next time someone asks.
- Tag the person who needs this.
- Post this on your story if it helped.
- Share with your team before your next meeting.

## Save lines
- Screenshot this rule.
- The [number] step checklist. Save it.
- Bookmark this for later.

## Comment lines (low effort)
- A or B?
- Which one are you?
- Type 1, 2 or 3.
- What should I explain next?
- One word. How do you feel about [thing]?

## Buy lines (honest)
Structure: problem, result, one action.
- Problem frame: "[Pain] takes [time]."
- Result frame: "[Product] does it in [real time]."
- Action: "Get it at [link]." or "Join the waitlist."
Rules: use only true claims, real numbers, real testimonials. No countdown timers you cannot honour.

## Reply and follow triggers
- Part 2 tomorrow: [teaser].
- Follow for the next [number] in this series.
- Reply with your [thing] and I will [do something real].
