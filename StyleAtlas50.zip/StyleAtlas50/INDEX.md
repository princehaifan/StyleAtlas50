# Style index

## Hand-Drawn

- 01 Whiteboard Marker: Dry-erase whiteboard with wobbly marker strokes, smudged ghost lines of erased earlier drawings and a tray shadow at the bottom edge.
- 02 Chalkboard Classroom: Dark green slate with chalk dust, thick chalk strokes and a wooden ledge.
- 03 Sketchnote Doodle: Cream notebook page with fat doodled outlines, banners, stars and highlighter swipes.
- 04 Blueprint Technical: White linework on cyan blueprint paper with dimension lines, grid and title block.
- 05 Napkin Sketch: Ballpoint drawing on a creased paper napkin with coffee ring stains.
- 06 Pencil Storyboard: Graphite sketches on toned paper with construction lines and smudged shading.
- 07 Crayon Kid Drawing: Waxy crayon scribbles on white paper with fat outlines and unfilled gaps.

## Painterly

- 08 Watercolor Bloom: Wet-on-wet watercolor washes that bloom outward with pigment edges and paper tooth.
- 09 Oil Paint Impasto: Thick oil strokes with visible bristle ridges and lit paint relief.
- 10 Gouache Poster: Flat matte gouache shapes with slightly uneven edges and chalky color.
- 11 Ink Wash Sumi-e: Black ink brush and wash with generous white space and one red seal.

## Print

- 12 Risograph Duotone: Two-ink riso print in pink and blue with misregistration and halftone grain.
- 13 Woodblock Ukiyo: Japanese woodblock print with flat color, bold outlines and wood grain.
- 14 Linocut Stamp: Heavy black linocut shapes with carved white lines and rough edges.

## Paper & Craft

- 15 Paper Cutout Layers: Layered cut paper with soft drop shadows between layers and deckled edges.
- 16 Origami Fold: Shapes fold from flat paper into creatures and objects with crease shading.
- 17 Cardboard Craft: Corrugated cardboard cutouts with tape, marker labels and shipping stamps.
- 18 Felt and Stitch: Soft felt shapes with visible stitching and fuzzy edges.
- 19 Clay Stop-Motion: Clay figures with thumbprints, stepped 8 fps motion and tabletop lighting.
- 20 Sticker Bomb: Die-cut stickers with white borders slapped on a collage wall.

## Retro Digital

- 21 8-Bit Pixel Quest: Chunky pixel art game screen with dialog box and limited palette.
- 22 16-Bit Platformer: Parallax side-scroller landscape with sprites and HUD.
- 23 Terminal Hacker: Green phosphor terminal with typed commands and output.
- 24 VHS Camcorder: 90s tape playback with tracking glitches, date stamp and REC dot.
- 25 Windows 95 Desktop: Grey bevelled windows, blue title bars and pixel icons on a teal desktop.
- 26 Gameboy Green: Four-shade olive LCD with pixel ghosting.
- 27 ASCII Matrix: Falling character columns and images drawn in text.

## Retro UI & Neon

- 28 Synthwave Sunset: Magenta and cyan grid horizon with a striped sun.
- 29 Neon Sign Bar: Glowing neon tubes on a dark brick wall.
- 30 Cyberpunk HUD: Angular HUD overlays with scan data, glitch and hot pink on dark.
- 31 Vaporwave Mall: Pastel pink and teal with marble busts, grids and sunset gradients.
- 32 Retro Arcade Cabinet: Arcade attract screen with marquee lights and a score board.
- 33 Terminal Dashboard Glow: Dark analytics dashboard with glowing charts and live tickers.

## Dimensional

- 34 Isometric Pastel: True 30 degree isometric tiles with three-tone flat faces and long soft shadows.
- 35 Voxel Diorama: MagicaVoxel-style island with cube faces and soft shadows.
- 36 Soft 3D Clay: Puffy pastel 3D objects with soft shadows and glossy highlights.
- 37 Glassmorphism UI: Frosted glass cards floating over vivid gradient blobs.
- 38 Hidden-Line Wireframe: Phosphor-cyan wire mesh landscape with true hidden-line removal.

## Cosmic & Psychedelic

- 39 Neon Particle Galaxy: Thousands of glowing particles forming shapes in deep space.

## Art & Design Movements

- 40 Comic Halftone Pop: Pop-art comic panels with Ben-Day dots, thick outlines and speech bursts.
- 41 Newspaper Collage: Torn newsprint, cut headlines and ransom-note type on a desk.
- 43 Bauhaus Geometry: Primary shapes, strict grid and diagonal composition.
- 46 Memphis Pattern Party: 80s Memphis squiggles, confetti and clashing colors.
- 47 Art Deco Gold: Gold linework on black with fan motifs and symmetry.
- 50 Mosaic Tile: Hundreds of small tiles forming images with grout lines.

## Light & Imaging

- 42 Film Noir Spotlight: High contrast black and white with venetian blind shadows and a single red accent.
- 49 Stained Glass Window: Colored glass panes separated by lead lines with light shafts.

## Generative & Type

- 44 Swiss Grid Typographic: Giant Helvetica-style type on a strict grid with red accent.
- 45 Kinetic Typography: Words as the whole animation, scaled and timed to beats.

## Popular Explainer Looks

- 48 Infographic Flat: Clean flat vector icons with big numbers, bars and arrows on a soft background.

