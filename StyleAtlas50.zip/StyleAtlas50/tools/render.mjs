// Usage: node tools/render.mjs your-animation.html out.mp4
// Needs: npm i puppeteer, and ffmpeg on PATH. Not run in this pack's build, test on a short clip first.
import puppeteer from 'puppeteer';
import { spawn } from 'node:child_process';
import fs from 'node:fs';
const [,, file, out = 'out.mp4'] = process.argv;
const fps = 30;
const browser = await puppeteer.launch({ headless: 'new', args: ['--autoplay-policy=no-user-gesture-required'] });
const page = await browser.newPage();
await page.setViewport({ width: 1280, height: 720 });
await page.goto('file://' + fs.realpathSync(file));
await page.waitForFunction('window.seek && window.DURATION');
const dur = await page.evaluate('window.DURATION');
const frames = Math.ceil(dur * fps);
// audio
const audio = await page.evaluate(async () => {
  const r = await SOUND.renderOffline(window.scoreSound, window.DURATION, 48000, { voiceover: false });
  return Array.from(r.inter);
});
fs.writeFileSync('audio.f32', Buffer.from(new Float32Array(audio).buffer));
const ff = spawn('ffmpeg', ['-y', '-f', 'image2pipe', '-framerate', String(fps), '-i', '-',
  '-f', 'f32le', '-ar', '48000', '-ac', '2', '-i', 'audio.f32',
  '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-shortest', out], { stdio: ['pipe', 'inherit', 'inherit'] });
const canvas = await page.$('canvas');
for (let i = 0; i < frames; i++) {
  await page.evaluate((t) => window.seek(t), i / fps);
  ff.stdin.write(await canvas.screenshot({ type: 'png' }));
}
ff.stdin.end();
await new Promise((r) => ff.on('close', r));
await browser.close();
fs.unlinkSync('audio.f32');
