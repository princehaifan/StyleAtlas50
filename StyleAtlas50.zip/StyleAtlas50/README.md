# Style Atlas 50

Fifty reusable prompts. Each one makes Claude build a self-contained animated explainer (HTML canvas plus synthesized sound, renderable to MP4) in one visual style, with a retention engine built in.

## Quick start
1. Open `index.html` in a browser. Search or filter by family.
2. Press Copy prompt.
3. Paste it into Claude.
4. Fill in the brief at the top (topic, viewer, goal, one thing to remember, CTA, length).
5. Claude makes a visual storyboard first. Approve or edit it.
6. Claude builds the animation. Optionally render to MP4 with `tools/render.mjs`.

## What is in the zip
- `index.html`: picker with copy buttons, works offline
- `prompts/full/`: 50 self-contained prompts with the helper library and sound kit pasted in. Use these in Claude chat.
- `prompts/lite/`: the same 50 without the code blocks. Use in Claude Code where `lib/` sits next to the prompt.
- `lib/harness.js`, `lib/sound.js`: the shared helper library and synthesized sound kit
- `playbooks/`: viral playbook, 50-line hook bank, share/save/comment/buy triggers, brief template and a quick style picker
- `INDEX.md`, `INDEX.csv`: every style at a glance
- `tools/render.mjs`: frame-by-frame MP4 render script

## Honest notes
- Nothing can guarantee 100 percent open, retention, watch time, shares or sales. These prompts build in the mechanics known to help (fast hook, open loop, pattern interrupts, loop-able ending, share and save lines, one honest CTA). Test hook variants to see what your audience rewards. See `playbooks/VIRAL_PLAYBOOK.md`.
- Only the Low-Poly Faceted look had a full reference source in the original brief. These 50 prompts describe each style as a detailed card (palette, surface texture, lettering, motion, sound). Claude writes the drawing code from the card. Expect to iterate on the storyboard for the best fidelity.
- `render.mjs` was not run during the build of this pack. Try it on a short clip first.
- Styles are inspired by general visual traditions. Do not ask for named copyrighted characters or brands inside them.
- The helper library and sound kit are used as supplied in the source brief.
